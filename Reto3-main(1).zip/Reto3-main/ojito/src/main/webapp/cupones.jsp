<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cupones - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="cupones-header">
        <div class="container">
            <h1>Paquetes de Cupones</h1>
            <p>Adquiere cup ones para disfrutar de nuestras salas de escape online. Cada cupón te permite acceder a una partida.</p>
        </div>
    </section>

    <section class="cupones-info">
        <div class="container">
            <div class="info-card">
                <h2>¿Cómo funcionan los cupones?</h2>
                <p>Los cupones son la moneda de BilboSKP para acceder a nuestras salas de escape online. Cada vez que inicies una partida, se descontará un cupón de tu saldo.</p>
                <ul>
                    <li>Al registrarte como usuario normal, recibes 1 cupón gratuito.</li>
                    <li>Los centros educativos reciben tantos cupones como alumnos matriculados.</li>
                    <li>Puedes adquirir más cupones a través de nuestros paquetes.</li>
                    <li>Los cupones no tienen fecha de caducidad.</li>
                    <li>Los cupones pueden ser devueltos si no han sido utilizados y no ha pasado más de un mes desde su compra.</li>
                </ul>
            </div>
        </div>
    </section>

    <section class="paquetes-cupones">
        <div class="container">
            <h2 class="section-title">Nuestros Paquetes</h2>
            
            <div class="coupon-packages">
                <div class="coupon-package">
                    <h3 class="package-title">Pack Simple</h3>
                    <p class="package-price">5€</p>
                    <div class="package-details">
                        <p>4 cupones</p>
                        <p>1,25€ por cupón</p>
                        <p>Ideal para jugadores ocasionales</p>
                    </div>
                    <a href="comprar-cupones.jsp?pack=simple" class="btn btn-primary">Comprar Pack</a>
                </div>
                
                <div class="coupon-package featured">
                    <div class="package-badge">Más Popular</div>
                    <h3 class="package-title">Pack Familiar</h3>
                    <p class="package-price">10€</p>
                    <div class="package-details">
                        <p>10 cupones</p>
                        <p>1€ por cupón</p>
                        <p>Perfecto para compartir con amigos y familia</p>
                    </div>
                    <a href="comprar-cupones.jsp?pack=familiar" class="btn btn-secondary">Comprar Pack</a>
                </div>
                
                <div class="coupon-package">
                    <div class="package-badge">Mejor Valor</div>
                    <h3 class="package-title">Pack Ahorro</h3>
                    <p class="package-price">12€</p>
                    <div class="package-details">
                        <p>15 cupones</p>
                        <p>0,80€ por cupón</p>
                        <p>La opción más económica para jugadores frecuentes</p>
                    </div>
                    <a href="comprar-cupones.jsp?pack=ahorro" class="btn btn-primary">Comprar Pack</a>
                </div>
            </div>
        </div>
    </section>

    <section class="centros-educativos">
        <div class="container">
            <div class="info-card">
                <h2>Para Centros Educativos</h2>
                <p>Los centros educativos reciben cupones gratuitos según el número de alumnos matriculados. Estos cupones pueden ser utilizados en salas exclusivas para centros educativos.</p>
                <p>Además, los centros pueden solicitar cupones adicionales de forma gratuita para salas específicas de centros.</p>
                <a href="login.jsp" class="btn btn-secondary">Acceder como Centro</a>
            </div>
        </div>
    </section>

    <section class="preguntas-frecuentes">
        <div class="container">
            <h2 class="section-title">Preguntas Frecuentes</h2>
            
            <div class="faq-list">
                <div class="faq-item">
                    <div class="faq-question">¿Puedo devolver los cupones que no he utilizado?</div>
                    <div class="faq-answer">
                        <p>Sí, los cupones pueden ser devueltos siempre que no hayan sido utilizados y no haya transcurrido más de un mes desde la compra. En ese caso, se realizará un reembolso.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">¿Los cupones tienen fecha de caducidad?</div>
                    <div class="faq-answer">
                        <p>No, los cupones no tienen fecha de caducidad. Puedes utilizarlos cuando quieras.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">¿Puedo usar mis cupones en cualquier sala?</div>
                    <div class="faq-answer">
                        <p>Los usuarios normales pueden utilizar sus cupones en cualquier sala, excepto en las exclusivas para centros educativos. Los centros educativos pueden utilizar sus cupones en todas las salas.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">¿Qué ocurre con mis cupones si cancelo mi suscripción?</div>
                    <div class="faq-answer">
                        <p>Si cancelas tu suscripción, perderás todos los cupones que no hayas utilizado.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">¿Cómo puedo solicitar cupones adicionales como centro educativo?</div>
                    <div class="faq-answer">
                        <p>Los centros educativos pueden solicitar cupones adicionales de forma gratuita desde su panel de control, siempre que sean para salas específicas de centros.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Script para las preguntas frecuentes
        document.addEventListener('DOMContentLoaded', function() {
            const faqQuestions = document.querySelectorAll('.faq-question');
            
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    const answer = this.nextElementSibling;
                    const isOpen = answer.style.maxHeight;
                    
                    // Cerrar todas las respuestas
                    document.querySelectorAll('.faq-answer').forEach(a => {
                        a.style.maxHeight = null;
                    });
                    
                    // Abrir la respuesta seleccionada si estaba cerrada
                    if (!isOpen) {
                        answer.style.maxHeight = answer.scrollHeight + 'px';
                    }
                });
            });
        });
    </script>
</body>
</html>
