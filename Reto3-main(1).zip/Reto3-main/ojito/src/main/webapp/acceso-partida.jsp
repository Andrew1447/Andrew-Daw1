<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso a Partida - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="acceso-partida">
        <div class="container">
            <div class="form-container">
                <h2 class="form-title">Acceso a Partida</h2>
                <p class="form-description">Introduce el código de acceso proporcionado por tu centro educativo para acceder a la partida.</p>
                
                <form action="AccesoPartidaServlet" method="post">
                    <div class="form-group">
                        <label for="codigo">Código de Acceso</label>
                        <input type="text" id="codigo" name="codigo" class="form-control" required placeholder="Ej: TES4A2025">
                    </div>
                    
                    <div class="form-group">
                        <label for="nombre">Nombre del Alumno</label>
                        <input type="text" id="nombre" name="nombre" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Acceder a la Partida</button>
                    </div>
                    
                    <p class="form-note">Si no tienes un código de acceso, contacta con tu profesor o centro educativo.</p>
                </form>
            </div>
        </div>
    </section>

    <section class="acceso-info">
        <div class="container">
            <div class="info-card">
                <h2>¿Cómo funciona?</h2>
                
                <ol>
                    <li>Tu centro educativo organiza una partida en una sala de escape.</li>
                    <li>Recibes un código de acceso único para esa partida.</li>
                    <li>Introduces el código y tu nombre en este formulario.</li>
                    <li>Accedes a la sala de escape y juegas.</li>
                    <li>Tu puntuación se registra y contribuye a la puntuación total de tu aula.</li>
                </ol>
                <p>Cada alumno solo puede acceder una vez a la misma partida, así que ¡da lo mejor de ti!</p>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
