<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Partida - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                    <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                    <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                    <li><a href="ranking-centro.jsp">Rankings</a></li>
                    <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="crear-partida">
        <div class="container">
            <div class="form-container wide-form">
                <h2 class="form-title">Crear Nueva Partida</h2>
                <p class="form-description">Complete el siguiente formulario para crear una nueva partida para sus alumnos.</p>
                
                <form action="CrearPartidaServlet" method="post">
                    <div class="form-section">
                        <h3>Información Básica</h3>
                        
                        <div class="form-group">
                            <label for="aula">Nombre del Aula</label>
                            <input type="text" id="aula" name="aula" class="form-control" required placeholder="Ej: 4ºA, Grupo Ciencias, etc.">
                        </div>
                        
                        <div class="form-group">
                            <label for="sala">Sala de Escape</label>
                            <select id="sala" name="sala" class="form-control" required>
                                <option value="">Seleccione una sala</option>
                                <option value="3">El Tesoro Perdido (Dificultad: Baja)</option>
                                <option value="6">Matemáticas Divertidas (Dificultad: Baja)</option>
                                <option value="7">Ciencia en Acción (Dificultad: Media)</option>
                                <option value="8">Historia Interactiva (Dificultad: Media)</option>
                                <option value="9">Programación Básica (Dificultad: Alta)</option>
                            </select>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group half">
                                <label for="dificultad">Dificultad</label>
                                <select id="dificultad" name="dificultad" class="form-control" required>
                                    <option value="baja">Baja</option>
                                    <option value="media">Media</option>
                                    <option value="alta">Alta</option>
                                </select>
                            </div>
                            
                            <div class="form-group half">
                                <label for="jugadores">Número de Jugadores</label>
                                <input type="number" id="jugadores" name="jugadores" class="form-control" min="1" required>
                                <p class="form-note">Se descontará 1 cupón por cada jugador.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3>Programación</h3>
                        
                        <div class="form-row">
                            <div class="form-group half">
                                <label for="fecha">Fecha de Inicio</label>
                                <input type="date" id="fecha" name="fecha" class="form-control" required>
                            </div>
                            
                            <div class="form-group half">
                                <label for="hora">Hora de Inicio</label>
                                <input type="time" id="hora" name="hora" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="duracion">Duración Estimada (minutos)</label>
                            <select id="duracion" name="duracion" class="form-control">
                                <option value="30">30 minutos</option>
                                <option value="45">45 minutos</option>
                                <option value="60" selected>60 minutos</option>
                                <option value="90">90 minutos</option>
                                <option value="120">120 minutos</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3>Opciones Adicionales</h3>
                        
                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="ranking" name="ranking" checked>
                                <label for="ranking">Incluir en el ranking del centro</label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="notificacion" name="notificacion">
                                <label for="notificacion">Enviar notificación a los alumnos cuando la partida esté disponible</label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="notas">Notas Adicionales (opcional)</label>
                            <textarea id="notas" name="notas" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-summary">
                        <h3>Resumen</h3>
                        <div class="summary-content">
                            <p><strong>Cupones Disponibles:</strong> <span id="cupones-disponibles">120</span></p>
                            <p><strong>Cupones Necesarios:</strong> <span id="cupones-necesarios">0</span></p>
                            <p><strong>Cupones Restantes:</strong> <span id="cupones-restantes">120</span></p>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Crear Partida</button>
                        <a href="partidas-centro.jsp" class="btn btn-outline">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                        <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                        <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                        <li><a href="ranking-centro.jsp">Rankings</a></li>
                        <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Script para actualizar el resumen de cupones
        document.addEventListener('DOMContentLoaded', function() {
            const jugadoresInput = document.getElementById('jugadores');
            const cuponesDisponibles = document.getElementById('cupones-disponibles');
            const cuponesNecesarios = document.getElementById('cupones-necesarios');
            const cuponesRestantes = document.getElementById('cupones-restantes');
            
            jugadoresInput.addEventListener('input', function() {
                const disponibles = parseInt(cuponesDisponibles.textContent);
                const necesarios = parseInt(this.value) || 0;
                const restantes = disponibles - necesarios;
                
                cuponesNecesarios.textContent = necesarios;
                cuponesRestantes.textContent = restantes;
                
                // Cambiar color si no hay suficientes cupones
                if (restantes < 0) {
                    cuponesRestantes.style.color = 'red';
                } else {
                    cuponesRestantes.style.color = 'inherit';
                }
            });
            
            // Actualizar dificultad automáticamente al seleccionar sala
            const salaSelect = document.getElementById('sala');
            const dificultadSelect = document.getElementById('dificultad');
            
            salaSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                if (selectedOption.text.includes('Baja')) {
                    dificultadSelect.value = 'baja';
                } else if (selectedOption.text.includes('Media')) {
                    dificultadSelect.value = 'media';
                } else if (selectedOption.text.includes('Alta')) {
                    dificultadSelect.value = 'alta';
                }
            });
        });
    </script>
</body>
</html>
