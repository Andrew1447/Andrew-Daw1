<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Centro Educativo - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                    <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                    <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                    <li><a href="ranking-centro.jsp">Rankings</a></li>
                    <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="dashboard-header">
        <div class="container">
            <h1>Bienvenido, <span id="nombre-centro">Centro Educativo</span></h1>
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Cupones Disponibles</h3>
                    <p class="stat-value">120</p>
                    <a href="solicitar-cupones.jsp" class="btn btn-secondary">Solicitar Más</a>
                </div>
                <div class="stat-card">
                    <h3>Partidas Organizadas</h3>
                    <p class="stat-value">8</p>
                </div>
                <div class="stat-card">
                    <h3>Alumnos Participantes</h3>
                    <p class="stat-value">180</p>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-content">
        <div class="container">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Partidas Activas</h2>
                    <a href="crear-partida.jsp" class="btn btn-primary">Crear Nueva Partida</a>
                </div>
                
                <div class="partidas-list">
                    <div class="partida-card">
                        <div class="partida-header">
                            <h3>El Tesoro Perdido - 4ºA</h3>
                            <span class="partida-status active">Activa</span>
                        </div>
                        <div class="partida-details">
                            <p><strong>Código de Acceso:</strong> <span class="access-code">TES4A2025</span></p>
                            <p><strong>Fecha de Inicio:</strong> 15/04/2025</p>
                            <p><strong>Jugadores:</strong> 25</p>
                            <p><strong>Dificultad:</strong> Baja</p>
                        </div>
                        <div class="partida-actions">
                            <a href="detalle-partida.jsp?id=1" class="btn btn-secondary">Ver Detalles</a>
                            <a href="editar-partida.jsp?id=1" class="btn btn-outline">Editar</a>
                        </div>
                    </div>
                    
                    <div class="partida-card">
                        <div class="partida-header">
                            <h3>Matemáticas Divertidas - 3ºB</h3>
                            <span class="partida-status active">Activa</span>
                        </div>
                        <div class="partida-details">
                            <p><strong>Código de Acceso:</strong> <span class="access-code">MAT3B2025</span></p>
                            <p><strong>Fecha de Inicio:</strong> 12/04/2025</p>
                            <p><strong>Jugadores:</strong> 22</p>
                            <p><strong>Dificultad:</strong> Baja</p>
                        </div>
                        <div class="partida-actions">
                            <a href="detalle-partida.jsp?id=2" class="btn btn-secondary">Ver Detalles</a>
                            <a href="editar-partida.jsp?id=2" class="btn btn-outline">Editar</a>
                        </div>
                    </div>
                    
                    <div class="partida-card">
                        <div class="partida-header">
                            <h3>Ciencia en Acción - 2ºA</h3>
                            <span class="partida-status pending">Pendiente</span>
                        </div>
                        <div class="partida-details">
                            <p><strong>Código de Acceso:</strong> <span class="access-code">Pendiente</span></p>
                            <p><strong>Fecha de Inicio:</strong> 20/04/2025</p>
                            <p><strong>Jugadores:</strong> 18</p>
                            <p><strong>Dificultad:</strong> Media</p>
                        </div>
                        <div class="partida-actions">
                            <a href="detalle-partida.jsp?id=3" class="btn btn-secondary">Ver Detalles</a>
                            <a href="editar-partida.jsp?id=3" class="btn btn-outline">Editar</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-section">
                <h2>Salas Recomendadas para Centros</h2>
                <div class="escape-rooms">
                    <div class="escape-room">
                        <img src="images/sala3.jpg" alt="El Tesoro Perdido" class="escape-room-img">
                        <div class="escape-room-content">
                            <h3 class="escape-room-title">El Tesoro Perdido</h3>
                            <span class="escape-room-difficulty">Dificultad: Baja</span>
                            <p class="escape-room-description">Una aventura de aprendizaje en busca de un tesoro histórico. Perfecto para estudiantes de todas las edades.</p>
                            <div class="escape-room-actions">
                                <span class="escape-room-price">1 Cupón por alumno</span>
                                <a href="crear-partida.jsp?sala=3" class="btn btn-primary">Crear Partida</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="escape-room">
                        <img src="images/sala6.jpg" alt="Matemáticas Divertidas" class="escape-room-img">
                        <div class="escape-room-content">
                            <h3 class="escape-room-title">Matemáticas Divertidas</h3>
                            <span class="escape-room-difficulty">Dificultad: Baja</span>
                            <p class="escape-room-description">Aprende matemáticas de forma divertida resolviendo enigmas y puzzles. Adaptado a diferentes niveles.</p>
                            <div class="escape-room-actions">
                                <span class="escape-room-price">1 Cupón por alumno</span>
                                <a href="crear-partida.jsp?sala=6" class="btn btn-primary">Crear Partida</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-section">
                <h2>Resumen de Rankings</h2>
                <div class="rankings-summary">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Aula</th>
                                <th>Sala</th>
                                <th>Puntuación Media</th>
                                <th>Participantes</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>4ºA</td>
                                <td>El Tesoro Perdido</td>
                                <td>85/100</td>
                                <td>25/25</td>
                                <td><span class="badge success">Completada</span></td>
                            </tr>
                            <tr>
                                <td>3ºB</td>
                                <td>Matemáticas Divertidas</td>
                                <td>78/100</td>
                                <td>18/22</td>
                                <td><span class="badge warning">En Progreso</span></td>
                            </tr>
                            <tr>
                                <td>2ºA</td>
                                <td>Ciencia en Acción</td>
                                <td>-</td>
                                <td>0/18</td>
                                <td><span class="badge info">Pendiente</span></td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="ranking-centro.jsp" class="btn btn-secondary">Ver Rankings Completos</a>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                        <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                        <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                        <li><a href="ranking-centro.jsp">Rankings</a></li>
                        <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
