<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="login">
        <div class="container">
            <div class="login-options">
                <div class="form-container">
                    <h2 class="form-title">Iniciar Sesión</h2>
                    
                    <ul class="login-tabs">
                        <li class="active" data-tab="usuario">Usuario</li>
                        <li data-tab="centro">Centro Educativo</li>
                        <li data-tab="admin">Administrador</li>
                    </ul>
                    
                    <div class="login-tab-content active" id="usuario-tab">
                        <form action="LoginServlet" method="post">
                            <input type="hidden" name="tipo" value="usuario">
                            
                            <div class="form-group">
                                <label for="usuario">Nombre de Usuario</label>
                                <input type="text" id="usuario" name="usuario" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Contraseña</label>
                                <input type="password" id="password" name="password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <div class="checkbox-group">
                                    <input type="checkbox" id="recordar" name="recordar">
                                    <label for="recordar">Recordarme</label>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Iniciar Sesión</button>
                            </div>
                            
                            <p class="form-note">¿No tienes una cuenta? <a href="registro.jsp">Regístrate aquí</a></p>
                        </form>
                    </div>
                    
                    <div class="login-tab-content" id="centro-tab">
                        <form action="LoginServlet" method="post">
                            <input type="hidden" name="tipo" value="centro">
                            
                            <div class="form-group">
                                <label for="centro">Nombre del Centro</label>
                                <input type="text" id="centro" name="centro" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="codigo">Código de Acceso</label>
                                <input type="text" id="codigo" name="codigo" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-secondary btn-block">Iniciar Sesión</button>
                            </div>
                            
                            <p class="form-note">¿No tienes un código? <a href="registro-centro.jsp">Solicítalo aquí</a></p>
                        </form>
                    </div>
                    
                    <div class="login-tab-content" id="admin-tab">
                        <form action="LoginServlet" method="post">
                            <input type="hidden" name="tipo" value="admin">
                            
                            <div class="form-group">
                                <label for="admin">Usuario Administrador</label>
                                <input type="text" id="admin" name="admin" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="admin-password">Contraseña</label>
                                <input type="password" id="admin-password" name="admin-password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-accent btn-block">Iniciar Sesión</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Script para las pestañas de inicio de sesión
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.login-tabs li');
            const tabContents = document.querySelectorAll('.login-tab-content');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // Desactivar todas las pestañas y contenidos
                    tabs.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(c => c.classList.remove('active'));
                    
                    // Activar la pestaña y contenido seleccionados
                    this.classList.add('active');
                    document.getElementById(tabId + '-tab').classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
