<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salas de Escape - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="salas-header">
        <div class="container">
            <h1>Nuestras Salas de Escape</h1>
            <p>Descubre todas nuestras emocionantes salas de escape online y vive una experiencia única.</p>
            
            <div class="salas-filtros">
                <div class="filtro">
                    <label for="dificultad">Dificultad:</label>
                    <select id="dificultad" name="dificultad">
                        <option value="todas">Todas</option>
                        <option value="baja">Baja</option>
                        <option value="media">Media</option>
                        <option value="alta">Alta</option>
                    </select>
                </div>
                
                <div class="filtro">
                    <label for="tipo">Tipo:</label>
                    <select id="tipo" name="tipo">
                        <option value="todas">Todas</option>
                        <option value="general">General</option>
                        <option value="centro">Centro Educativo</option>
                    </select>
                </div>
                
                <div class="filtro">
                    <label for="duracion">Duración:</label>
                    <select id="duracion" name="duracion">
                        <option value="todas">Todas</option>
                        <option value="corta">Corta (30 min)</option>
                        <option value="media">Media (60 min)</option>
                        <option value="larga">Larga (90+ min)</option>
                    </select>
                </div>
                
                <button id="aplicar-filtros" class="btn btn-primary">Aplicar Filtros</button>
            </div>
        </div>
    </section>

    <section class="salas-lista">
        <div class="container">
            <div class="escape-rooms">
                <div class="escape-room">
                    <img src="images/sala1.jpg" alt="El Misterio de la Mansión" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">El Misterio de la Mansión</h3>
                        <span class="escape-room-difficulty">Dificultad: Media</span>
                        <p class="escape-room-description">Descubre los secretos ocultos en esta antigua mansión antes de que sea demasiado tarde. Una aventura llena de misterios y enigmas.</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 60 minutos</span>
                            <span><strong>Tipo:</strong> General</span>
                            <span><strong>Jugadores:</strong> 1-4</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón</span>
                            <a href="detalle-sala.jsp?id=1" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                
                <div class="escape-room">
                    <img src="images/sala2.jpg" alt="Laboratorio Z" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">Laboratorio Z</h3>
                        <span class="escape-room-difficulty">Dificultad: Alta</span>
                        <p class="escape-room-description">Un virus se ha escapado del laboratorio. Encuentra la cura antes de que sea demasiado tarde. ¿Podrás resolver todos los enigmas a tiempo?</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 90 minutos</span>
                            <span><strong>Tipo:</strong> General</span>
                            <span><strong>Jugadores:</strong> 1-4</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón</span>
                            <a href="detalle-sala.jsp?id=2" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                
                <div class="escape-room">
                    <img src="images/sala3.jpg" alt="El Tesoro Perdido" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">El Tesoro Perdido</h3>
                        <span class="escape-room-difficulty">Dificultad: Baja</span>
                        <p class="escape-room-description">Ideal para centros educativos. Una aventura de aprendizaje en busca de un tesoro histórico. Perfecto para estudiantes de todas las edades.</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 45 minutos</span>
                            <span><strong>Tipo:</strong> Centro Educativo</span>
                            <span><strong>Jugadores:</strong> 10-30</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón por alumno</span>
                            <a href="detalle-sala.jsp?id=3" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                
                <div class="escape-room">
                    <img src="images/sala4.jpg" alt="La Pirámide Olvidada" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">La Pirámide Olvidada</h3>
                        <span class="escape-room-difficulty">Dificultad: Media</span>
                        <p class="escape-room-description">Adéntrate en una antigua pirámide egipcia y descubre sus secretos. Cuidado con las trampas y maldiciones que te esperan.</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 60 minutos</span>
                            <span><strong>Tipo:</strong> General</span>
                            <span><strong>Jugadores:</strong> 1-4</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón</span>
                            <a href="detalle-sala.jsp?id=4" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                
                <div class="escape-room">
                    <img src="images/sala5.jpg" alt="Misión Espacial" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">Misión Espacial</h3>
                        <span class="escape-room-difficulty">Dificultad: Alta</span>
                        <p class="escape-room-description">Tu nave espacial ha sufrido una avería. Repara los sistemas antes de quedarte sin oxígeno. Una aventura llena de ciencia y tecnología.</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 75 minutos</span>
                            <span><strong>Tipo:</strong> General</span>
                            <span><strong>Jugadores:</strong> 1-4</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón</span>
                            <a href="detalle-sala.jsp?id=5" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
                
                <div class="escape-room">
                    <img src="images/sala6.jpg" alt="Matemáticas Divertidas" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">Matemáticas Divertidas</h3>
                        <span class="escape-room-difficulty">Dificultad: Baja</span>
                        <p class="escape-room-description">Especial para centros educativos. Aprende matemáticas de forma divertida resolviendo enigmas y puzzles. Adaptado a diferentes niveles.</p>
                        <div class="escape-room-details">
                            <span><strong>Duración:</strong> 40 minutos</span>
                            <span><strong>Tipo:</strong> Centro Educativo</span>
                            <span><strong>Jugadores:</strong> 10-30</span>
                        </div>
                        <div class="escape-room-actions">
                            <span class="escape-room-price">1 Cupón por alumno</span>
                            <a href="detalle-sala.jsp?id=6" class="btn btn-primary">Ver Detalles</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Script para filtrar salas
        document.addEventListener('DOMContentLoaded', function() {
            const btnFiltrar = document.getElementById('aplicar-filtros');
            const salas = document.querySelectorAll('.escape-room');
            
            btnFiltrar.addEventListener('click', function() {
                const dificultad = document.getElementById('dificultad').value;
                const tipo = document.getElementById('tipo').value;
                const duracion = document.getElementById('duracion').value;
                
                salas.forEach(sala => {
                    const salaInfo = sala.querySelector('.escape-room-content');
                    const salaDificultad = salaInfo.querySelector('.escape-room-difficulty').textContent.toLowerCase();
                    const salaTipo = salaInfo.querySelector('.escape-room-details span:nth-child(2)').textContent.toLowerCase();
                    const salaDuracion = salaInfo.querySelector('.escape-room-details span:nth-child(1)').textContent.toLowerCase();
                    
                    let mostrar = true;
                    
                    if (dificultad !== 'todas' && !salaDificultad.includes(dificultad.toLowerCase())) {
                        mostrar = false;
                    }
                    
                    if (tipo !== 'todas' && !salaTipo.includes(tipo.toLowerCase())) {
                        mostrar = false;
                    }
                    
                    if (duracion !== 'todas') {
                        if (duracion === 'corta' && !salaDuracion.includes('30')) {
                            mostrar = false;
                        } else if (duracion === 'media' && !salaDuracion.includes('60')) {
                            mostrar = false;
                        } else if (duracion === 'larga' && !salaDuracion.includes('90')) {
                            mostrar = false;
                        }
                    }
                    
                    sala.style.display = mostrar ? 'block' : 'none';
                });
            });
        });
    </script>
</body>
</html>
