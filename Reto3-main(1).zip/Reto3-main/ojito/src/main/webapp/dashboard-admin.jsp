<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-admin.jsp">Panel</a></li>
                    <li><a href="admin-usuarios.jsp">Usuarios</a></li>
                    <li><a href="admin-centros.jsp">Centros</a></li>
                    <li><a href="admin-salas.jsp">Salas</a></li>
                    <li><a href="admin-solicitudes.jsp">Solicitudes</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="dashboard-header">
        <div class="container">
            <h1>Panel de Administrador</h1>
            <div class="dashboard-stats">
                
                <div class="stat-card">
                    <h3>Usuarios Registrados</h3>
                    <p class="stat-value">245</p>
                </div>
                <div class="stat-card">
                    <h3>Centros Educativos</h3>
                    <p class="stat-value">18</p>
                </div>
                <div class="stat-card">
                    <h3>Salas de Escape</h3>
                    <p class="stat-value">12</p>
                </div>
                <div class="stat-card">
                    <h3>Solicitudes Pendientes</h3>
                    <p class="stat-value">3</p>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-content">
        <div class="container">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Solicitudes Pendientes</h2>
                    <a href="admin-solicitudes.jsp" class="btn btn-primary">Ver Todas</a>
                </div>
                
                <div class="solicitudes-list">
                    <div class="solicitud-card">
                        <div class="solicitud-header">
                            <h3>Colegio San José</h3>
                            <span class="solicitud-date">Recibida: 15/04/2025</span>
                        </div>
                        <div class="solicitud-details">
                            <p><strong>Localidad:</strong> Madrid</p>
                            <p><strong>Alumnos:</strong> 450</p>
                            <p><strong>Email:</strong> direccion@colegiosanjose.edu</p>
                        </div>
                        <div class="solicitud-actions">
                            <a href="aprobar-solicitud.jsp?id=1" class="btn btn-success">Aprobar</a>
                            <a href="rechazar-solicitud.jsp?id=1" class="btn btn-danger">Rechazar</a>
                            <a href="detalle-solicitud.jsp?id=1" class="btn btn-outline">Ver Detalles</a>
                        </div>
                    </div>
                    
                    <div class="solicitud-card">
                        <div class="solicitud-header">
                            <h3>IES Miguel de Cervantes</h3>
                            <span class="solicitud-date">Recibida: 14/04/2025</span>
                        </div>
                        <div class="solicitud-details">
                            <p><strong>Localidad:</strong> Barcelona</p>
                            <p><strong>Alumnos:</strong> 320</p>
                            <p><strong>Email:</strong> secretaria@iescervantes.edu</p>
                        </div>
                        <div class="solicitud-actions">
                            <a href="aprobar-solicitud.jsp?id=2" class="btn btn-success">Aprobar</a>
                            <a href="rechazar-solicitud.jsp?id=2" class="btn btn-danger">Rechazar</a>
                            <a href="detalle-solicitud.jsp?id=2" class="btn btn-outline">Ver Detalles</a>
                        </div>
                    </div>
                    
                    <div class="solicitud-card">
                        <div class="solicitud-header">
                            <h3>Escuela Primaria Arcoiris</h3>
                            <span class="solicitud-date">Recibida: 12/04/2025</span>
                        </div>
                        <div class="solicitud-details">
                            <p><strong>Localidad:</strong> Valencia</p>
                            <p><strong>Alumnos:</strong> 180</p>
                            <p><strong>Email:</strong> info@escuelaarcoiris.edu</p>
                        </div>
                        <div class="solicitud-actions">
                            <a href="aprobar-solicitud.jsp?id=3" class="btn btn-success">Aprobar</a>
                            <a href="rechazar-solicitud.jsp?id=3" class="btn btn-danger">Rechazar</a>
                            <a href="detalle-solicitud.jsp?id=3" class="btn btn-outline">Ver Detalles</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Actividad Reciente</h2>
                </div>
                
                <div class="activity-list">
                    <div class="activity-item">
                        <div class="activity-icon user-icon"></div>
                        <div class="activity-content">
                            <p class="activity-text"><strong>Usuario Nuevo:</strong> Se ha registrado un nuevo usuario (usuario123).</p>
                            <p class="activity-date">Hoy, 10:45</p>
                        </div>
                        <div class="activity-actions">
                            <a href="admin-usuarios.jsp?id=123" class="btn btn-outline">Ver Usuario</a>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon center-icon"></div>
                        <div class="activity-content">
                            <p class="activity-text"><strong>Centro Aprobado:</strong> Se ha aprobado el centro "IES García Lorca".</p>
                            <p class="activity-date">Hoy, 09:30</p>
                        </div>
                        <div class="activity-actions">
                            <a href="admin-centros.jsp?id=18" class="btn btn-outline">Ver Centro</a>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon subscription-icon"></div>
                        <div class="activity-content">
                            <p class="activity-text"><strong>Suscripción Cancelada:</strong> El usuario "maria85" ha cancelado su suscripción.</p>
                            <p class="activity-date">Ayer, 16:20</p>
                        </div>
                        <div class="activity-actions">
                            <a href="admin-usuarios.jsp?id=85" class="btn btn-outline">Ver Usuario</a>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon room-icon"></div>
                        <div class="activity-content">
                            <p class="activity-text"><strong>Sala Modificada:</strong> Se ha actualizado la sala "El Tesoro Perdido".</p>
                            <p class="activity-date">Ayer, 14:15</p>
                        </div>
                        <div class="activity-actions">
                            <a href="admin-salas.jsp?id=3" class="btn btn-outline">Ver Sala</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Estadísticas Generales</h2>
                </div>
                
                <div class="stats-grid">
                    <div class="stats-card">
                        <h3>Usuarios por Tipo</h3>
                        <div class="stats-chart pie-chart">
                            <!-- Aquí iría un gráfico de pastel -->
                            <div class="chart-placeholder">Gráfico: 245 Usuarios, 18 Centros</div>
                        </div>
                    </div>
                    
                    <div class="stats-card">
                        <h3>Partidas por Mes</h3>
                        <div class="stats-chart bar-chart">
                            <!-- Aquí iría un gráfico de barras -->
                            <div class="chart-placeholder">Gráfico: Partidas mensuales</div>
                        </div>
                    </div>
                    
                    <div class="stats-card">
                        <h3>Salas más Populares</h3>
                        <div class="stats-chart bar-chart">
                            <!-- Aquí iría un gráfico de barras -->
                            <div class="chart-placeholder">Gráfico: Popularidad de salas</div>
                        </div>
                    </div>
                    
                    <div class="stats-card">
                        <h3>Ingresos Mensuales</h3>
                        <div class="stats-chart line-chart">
                            <!-- Aquí iría un gráfico de líneas -->
                            <div class="chart-placeholder">Gráfico: Ingresos por mes</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-admin.jsp">Panel</a></li>
                        <li><a href="admin-usuarios.jsp">Usuarios</a></li>
                        <li><a href="admin-centros.jsp">Centros</a></li>
                        <li><a href="admin-salas.jsp">Salas</a></li>
                        <li><a href="admin-solicitudes.jsp">Solicitudes</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: admin@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
