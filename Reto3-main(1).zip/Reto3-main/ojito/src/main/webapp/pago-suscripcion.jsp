<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago de Suscripción - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="pago-suscripcion">
        <div class="container">
            <div class="form-container">
                <h2 class="form-title">Pago de Suscripción</h2>
                <p class="form-description">Para completar tu registro, realiza el pago de la suscripción de 15€.</p>
                
                <div class="subscription-details">
                    <h3>Detalles de la Suscripción</h3>
                    <ul>
                        <li>Acceso a todas las salas de escape generales</li>
                        <li>1 cupón gratuito al registrarte</li>
                        <li>Posibilidad de comprar paquetes de cupones adicionales</li>
                    </ul>
                    <p class="price">Precio: <span>15€</span></p>
                </div>
                
                <form action="PagoServlet" method="post">
                    <div class="form-group">
                        <label for="nombre">Nombre Completo</label>
                        <input type="text" id="nombre" name="nombre" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Correo Electrónico</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="tarjeta">Número de Tarjeta</label>
                        <input type="text" id="tarjeta" name="tarjeta" class="form-control" required pattern="[0-9]{16}" placeholder="1234 5678 9012 3456">
                    
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group half">
                            <label for="caducidad">Fecha de Caducidad</label>
                            <input type="text" id="caducidad" name="caducidad" class="form-control" required pattern="[0-9]{2}/[0-9]{2}" placeholder="MM/AA">
                        </div>
                        
                        <div class="form-group half">
                            <label for="cvv">CVV</label>
                            <input type="text" id="cvv" name="cvv" class="form-control" required pattern="[0-9]{3}" placeholder="123">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Pagar 15€ y Continuar</button>
                    </div>
                    
                    <p class="form-note">Al realizar el pago, aceptas nuestros <a href="#">Términos y Condiciones</a> y <a href="#">Política de Privacidad</a>.</p>
                </form>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
