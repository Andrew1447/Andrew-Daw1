<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jugar - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-usuario.jsp">Mi Panel</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="perfil-usuario.jsp">Mi Perfil</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="jugar-header">
        <div class="container">
            <h1>El Misterio de la Mansión</h1>
            <div class="jugar-info">
                <div class="jugar-details">
                    <p><strong>Dificultad:</strong> Media</p>
                    <p><strong>Duración Estimada:</strong> 60 minutos</p>
                    <p><strong>Costo:</strong> 1 Cupón</p>
                </div>
                <div class="jugar-cupones">
                    <p>Cupones Disponibles: <span>5</span></p>
                </div>
            </div>
        </div>
    </section>

    <section class="jugar-content">
        <div class="container">
            <div class="jugar-description">
                <h2>Descripción</h2>
                <p>Descubre los secretos ocultos en esta antigua mansión antes de que sea demasiado tarde. Una aventura llena de misterios y enigmas que pondrán a prueba tu ingenio y capacidad de deducción.</p>
                <p>La mansión ha estado abandonada durante décadas, pero los rumores sobre extraños sucesos y tesoros ocultos nunca han cesado. Ahora tienes la oportunidad de explorarla y descubrir la verdad detrás de las leyendas.</p>
                <p>¿Estás preparado para enfrentarte a los misterios que esconde esta antigua mansión?</p>
            </div>
            
            <div class="jugar-instrucciones">
                <h2>Instrucciones</h2>
                <ol>
                    <li>Al iniciar el juego, se descontará 1 cupón de tu saldo.</li>
                    <li>Descarga el juego utilizando el botón de abajo.</li>
                    <li>Ejecuta el archivo descargado para iniciar la sala de escape.</li>
                    <li>Sigue las instrucciones que aparecerán en pantalla.</li>
                    <li>Tu puntuación se registrará automáticamente al finalizar.</li>
                </ol>
            </div>
            
            <div class="jugar-requisitos">
                <h2>Requisitos del Sistema</h2>
                <ul>
                    <li><strong>Sistema Operativo:</strong> Windows 10/11, macOS 10.15+, Linux</li>
                    <li><strong>Procesador:</strong> Intel Core i3 o equivalente</li>
                    <li><strong>Memoria:</strong> 4 GB RAM</li>
                    <li><strong>Gráficos:</strong> Tarjeta gráfica compatible con OpenGL 3.3</li>
                    <li><strong>Almacenamiento:</strong> 500 MB de espacio disponible</li>
                    <li><strong>Conexión a Internet:</strong> Requerida para iniciar y finalizar la partida</li>
                </ul>
            </div>
            
            <div class="jugar-actions">
                <div class="confirmation-box">
                    <p>Al descargar e iniciar el juego, se descontará 1 cupón de tu saldo.</p>
                    <div class="checkbox-group">
                        <input type="checkbox" id="confirmar" name="confirmar" required>
                        <label for="confirmar">Entiendo y acepto que se descontará 1 cupón</label>
                    </div>
                </div>
                
                <button id="btn-descargar" class="btn btn-primary btn-large" disabled>Descargar y Jugar</button>
                <a href="salas.jsp" class="btn btn-outline">Volver a Salas</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-usuario.jsp">Mi Panel</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="perfil-usuario.jsp">Mi Perfil</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const confirmarCheckbox = document.getElementById('confirmar');
            const btnDescargar = document.getElementById('btn-descargar');
            
            confirmarCheckbox.addEventListener('change', function() {
                btnDescargar.disabled = !this.checked;
            });
            
            btnDescargar.addEventListener('click', function() {
                if (confirmarCheckbox.checked) {
                    // Simular descarga
                    alert('Descargando juego... Se ha descontado 1 cupón de tu saldo.');
                    
                    // Redireccionar a la página de descarga (simulado)
                    setTimeout(function() {
                        window.location.href = 'descarga-completada.jsp';
                    }, 2000);
                }
            });
        });
    </script>
</body>
</html>
