<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuario - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-usuario.jsp">Mi Panel</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="perfil-usuario.jsp">Mi Perfil</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="dashboard-header">
        <div class="container">
            <h1>Bienvenido, <span id="nombre-usuario">Usuario</span></h1>
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Cupones Disponibles</h3>
                    <p class="stat-value">5</p>
                    <a href="cupones.jsp" class="btn btn-secondary">Comprar Más</a>
                </div>
                <div class="stat-card">
                    <h3>Partidas Jugadas</h3>
                    <p class="stat-value">12</p>
                </div>
                <div class="stat-card">
                    <h3>Puntuación Media</h3>
                    <p class="stat-value">78/100</p>
                </div>
            </div>
        </div>
    </section>

    <section class="dashboard-content">
        <div class="container">
            <div class="dashboard-section">
                <h2>Salas Recomendadas</h2>
                <div class="escape-rooms">
                    <div class="escape-room">
                        <img src="images/sala1.jpg" alt="El Misterio de la Mansión" class="escape-room-img">
                        <div class="escape-room-content">
                            <h3 class="escape-room-title">El Misterio de la Mansión</h3>
                            <span class="escape-room-difficulty">Dificultad: Media</span>
                            <p class="escape-room-description">Descubre los secretos ocultos en esta antigua mansión antes de que sea demasiado tarde.</p>
                            <div class="escape-room-actions">
                                <span class="escape-room-price">1 Cupón</span>
                                <a href="jugar.jsp?id=1" class="btn btn-primary">Jugar Ahora</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="escape-room">
                        <img src="images/sala4.jpg" alt="La Pirámide Olvidada" class="escape-room-img">
                        <div class="escape-room-content">
                            <h3 class="escape-room-title">La Pirámide Olvidada</h3>
                            <span class="escape-room-difficulty">Dificultad: Media</span>
                            <p class="escape-room-description">Adéntrate en una antigua pirámide egipcia y descubre sus secretos.</p>
                            <div class="escape-room-actions">
                                <span class="escape-room-price">1 Cupón</span>
                                <a href="jugar.jsp?id=4" class="btn btn-primary">Jugar Ahora</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-section">
                <h2>Historial de Partidas</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Sala</th>
                            <th>Puntuación</th>
                            <th>Tiempo</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>15/04/2025</td>
                            <td>El Misterio de la Mansión</td>
                            <td>85/100</td>
                            <td>48:23</td>
                            <td><span class="badge success">Completada</span></td>
                        </tr>
                        <tr>
                            <td>10/04/2025</td>
                            <td>Laboratorio Z</td>
                            <td>72/100</td>
                            <td>65:12</td>
                            <td><span class="badge success">Completada</span></td>
                        </tr>
                        <tr>
                            <td>05/04/2025</td>
                            <td>La Pirámide Olvidada</td>
                            <td>90/100</td>
                            <td>52:45</td>
                            <td><span class="badge success">Completada</span></td>
                        </tr>
                        <tr>
                            <td>28/03/2025</td>
                            <td>Misión Espacial</td>
                            <td>65/100</td>
                            <td>70:18</td>
                            <td><span class="badge success">Completada</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="dashboard-section">
                <h2>Mis Cupones</h2>
                <div class="cupones-info">
                    <div class="cupones-disponibles">
                        <h3>Cupones Disponibles: <span>5</span></h3>
                        <a href="cupones.jsp" class="btn btn-primary">Comprar Más Cupones</a>
                    </div>
                    
                    <div class="historial-cupones">
                        <h3>Historial de Compras</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Paquete</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>12/04/2025</td>
                                    <td>Pack Familiar</td>
                                    <td>10 cupones</td>
                                    <td>10€</td>
                                </tr>
                                <tr>
                                    <td>01/03/2025</td>
                                    <td>Pack Simple</td>
                                    <td>4 cupones</td>
                                    <td>5€</td>
                                </tr>
                                <tr>
                                    <td>15/02/2025</td>
                                    <td>Registro</td>
                                    <td>1 cupón</td>
                                    <td>Gratis</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-usuario.jsp">Mi Panel</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="perfil-usuario.jsp">Mi Perfil</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
