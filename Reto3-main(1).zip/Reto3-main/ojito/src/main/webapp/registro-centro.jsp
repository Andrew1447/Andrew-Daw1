<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Centro Educativo - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="registro-centro">
        <div class="container">
            <div class="form-container">
                <h2 class="form-title">Registro de Centro Educativo</h2>
                <p class="form-description">Complete el siguiente formulario para solicitar el registro de su centro educativo. Una vez verificada la información, recibirá un código de acceso.</p>
                
                <form action="RegistroCentroServlet" method="post">
                    <div class="form-group">
                        <label for="nombre">Nombre del Centro</label>
                        <input type="text" id="nombre" name="nombre" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="alumnos">Número de Alumnos Matriculados</label>
                        <input type="number" id="alumnos" name="alumnos" class="form-control" min="1" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="localidad">Localidad</label>
                        <input type="text" id="localidad" name="localidad" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Correo Electrónico de Contacto</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="info">Información Adicional (opcional)</label>
                        <textarea id="info" name="info" class="form-control" rows="4"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Enviar Solicitud</button>
                    </div>
                    
                    <p class="form-note">Una vez enviada la solicitud, el administrador verificará la información y le enviará un código de acceso al correo electrónico proporcionado.</p>
                </form>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
