<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rankings - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                    <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                    <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                    <li><a href="ranking-centro.jsp">Rankings</a></li>
                    <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    <li><a href="LogoutServlet" class="btn btn-accent">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="ranking-header">
        <div class="container">
            <h1>Rankings del Centro</h1>
            <p>Aquí puedes ver los resultados de todas las partidas organizadas por tu centro educativo.</p>
            
            <div class="ranking-filtros">
                <div class="filtro">
                    <label for="sala">Sala:</label>
                    <select id="sala" name="sala">
                        <option value="todas">Todas</option>
                        <option value="3">El Tesoro Perdido</option>
                        <option value="6">Matemáticas Divertidas</option>
                        <option value="7">Ciencia en Acción</option>
                    </select>
                </div>
                
                <div class="filtro">
                    <label for="aula">Aula:</label>
                    <select id="aula" name="aula">
                        <option value="todas">Todas</option>
                        <option value="4A">4ºA</option>
                        <option value="3B">3ºB</option>
                        <option value="2A">2ºA</option>
                    </select>
                </div>
                
                <div class="filtro">
                    <label for="fecha">Fecha:</label>
                    <select id="fecha" name="fecha">
                        <option value="todas">Todas</option>
                        <option value="ultimo-mes">Último mes</option>
                        <option value="ultimo-trimestre">Último trimestre</option>
                        <option value="ultimo-año">Último año</option>
                    </select>
                </div>
                
                <button id="aplicar-filtros" class="btn btn-primary">Aplicar Filtros</button>
            </div>
        </div>
    </section>

    <section class="ranking-content">
        <div class="container">
            <div class="ranking-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Posición</th>
                            <th>Aula</th>
                            <th>Sala</th>
                            <th>Puntuación Media</th>
                            <th>Participantes</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="ranking-first">
                            <td>1</td>
                            <td>4ºA</td>
                            <td>El Tesoro Perdido</td>
                            <td>85/100</td>
                            <td>25/25</td>
                            <td>15/04/2025</td>
                            <td><a href="detalle-partida.jsp?id=1" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr class="ranking-second">
                            <td>2</td>
                            <td>2ºB</td>
                            <td>El Tesoro Perdido</td>
                            <td>82/100</td>
                            <td>20/20</td>
                            <td>10/04/2025</td>
                            <td><a href="detalle-partida.jsp?id=4" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr class="ranking-third">
                            <td>3</td>
                            <td>3ºB</td>
                            <td>Matemáticas Divertidas</td>
                            <td>78/100</td>
                            <td>18/22</td>
                            <td>12/04/2025</td>
                            <td><a href="detalle-partida.jsp?id=2" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>1ºA</td>
                            <td>El Tesoro Perdido</td>
                            <td>75/100</td>
                            <td>15/15</td>
                            <td>05/04/2025</td>
                            <td><a href="detalle-partida.jsp?id=5" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>3ºA</td>
                            <td>Matemáticas Divertidas</td>
                            <td>72/100</td>
                            <td>20/20</td>
                            <td>01/04/2025</td>
                            <td><a href="detalle-partida.jsp?id=6" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>4ºB</td>
                            <td>Ciencia en Acción</td>
                            <td>70/100</td>
                            <td>18/18</td>
                            <td>28/03/2025</td>
                            <td><a href="detalle-partida.jsp?id=7" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>2ºA</td>
                            <td>Ciencia en Acción</td>
                            <td>-</td>
                            <td>0/18</td>
                            <td>20/04/2025 (Pendiente)</td>
                            <td><a href="detalle-partida.jsp?id=3" class="btn btn-small">Ver Detalles</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="ranking-stats">
                <div class="stats-card">
                    <h3>Estadísticas Generales</h3>
                    <ul>
                        <li><strong>Partidas Totales:</strong> 7</li>
                        <li><strong>Alumnos Participantes:</strong> 116</li>
                        <li><strong>Puntuación Media Global:</strong> 77/100</li>
                        <li><strong>Sala Más Popular:</strong> El Tesoro Perdido (3 partidas)</li>
                        <li><strong>Aula con Mejor Rendimiento:</strong> 4ºA (85/100)</li>
                    </ul>
                </div>
                
                <div class="stats-card">
                    <h3>Comparativa por Salas</h3>
                    <div class="stats-chart">
                        <!-- Aquí iría un gráfico de barras -->
                        <div class="chart-placeholder">Gráfico: Puntuaciones por sala</div>
                    </div>
                </div>
                
                <div class="stats-card">
                    <h3>Evolución Temporal</h3>
                    <div class="stats-chart">
                        <!-- Aquí iría un gráfico de líneas -->
                        <div class="chart-placeholder">Gráfico: Evolución de puntuaciones</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="dashboard-centro.jsp">Mi Panel</a></li>
                        <li><a href="partidas-centro.jsp">Mis Partidas</a></li>
                        <li><a href="salas-centro.jsp">Salas Disponibles</a></li>
                        <li><a href="ranking-centro.jsp">Rankings</a></li>
                        <li><a href="perfil-centro.jsp">Mi Centro</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Script para filtrar rankings
        document.addEventListener('DOMContentLoaded', function() {
            const btnFiltrar = document.getElementById('aplicar-filtros');
            const filas = document.querySelectorAll('.ranking-table tbody tr');
            
            btnFiltrar.addEventListener('click', function() {
                const sala = document.getElementById('sala').value;
                const aula = document.getElementById('aula').value;
                const fecha = document.getElementById('fecha').value;
                
                filas.forEach(fila => {
                    const filaSala = fila.querySelector('td:nth-child(3)').textContent;
                    const filaAula = fila.querySelector('td:nth-child(2)').textContent;
                    const filaFecha = fila.querySelector('td:nth-child(6)').textContent;
                    
                    let mostrar = true;
                    
                    if (sala !== 'todas' && !filaSala.includes(sala)) {
                        mostrar = false;
                    }
                    
                    if (aula !== 'todas' && !filaAula.includes(aula)) {
                        mostrar = false;
                    }
                    
                    if (fecha !== 'todas') {
                        // Aquí iría la lógica para filtrar por fecha
                        // Simplificado para este ejemplo
                    }
                    
                    fila.style.display = mostrar ? 'table-row' : 'none';
                });
            });
        });
    </script>
</body>
</html>
