<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BilboSKP - Salas de Escape Online</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Bienvenido a BilboSKP</h1>
                <p>La mejor plataforma de salas de escape online para usuarios y centros educativos</p>
                <div class="hero-buttons">
                    <a href="registro.jsp" class="btn btn-primary">Registrarse</a>
                    <a href="salas.jsp" class="btn btn-secondary">Ver Salas</a>
                </div>
            </div>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <h2 class="section-title">¿Por qué elegir BilboSKP?</h2>
            <div class="features-grid">
                <div class="feature">
                    <h3>Para Usuarios</h3>
                    <p>Accede a emocionantes salas de escape online desde la comodidad de tu hogar.</p>
                    <ul>
                        <li>Suscripción por solo 15€</li>
                        <li>Cupón gratuito al registrarte</li>
                        <li>Paquetes de cupones a precios económicos</li>
                    </ul>
                </div>
                <div class="feature">
                    <h3>Para Centros Educativos</h3>
                    <p>Ofrece a tus alumnos una experiencia educativa única y divertida.</p>
                    <ul>
                        <li>Suscripción gratuita</li>
                        <li>Cupones gratuitos según número de alumnos</li>
                        <li>Salas exclusivas para centros</li>
                        <li>Sistema de rankings por aulas</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="escape-rooms-preview">
        <div class="container">
            <h2 class="section-title">Nuestras Salas Destacadas</h2>
            <div class="escape-rooms">
                <div class="escape-room">
                    <img src="images/sala1.jpg" alt="Sala de escape" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">El Misterio de la Mansión</h3>
                        <span class="escape-room-difficulty">Dificultad: Media</span>
                        <p class="escape-room-description">Descubre los secretos ocultos en esta antigua mansión antes de que sea demasiado tarde.</p>
                        <a href="salas.jsp" class="btn btn-primary">Ver Detalles</a>
                    </div>
                </div>
                <div class="escape-room">
                    <img src="images/sala2.jpg" alt="Sala de escape" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">Laboratorio Z</h3>
                        <span class="escape-room-difficulty">Dificultad: Alta</span>
                        <p class="escape-room-description">Un virus se ha escapado del laboratorio. Encuentra la cura antes de que sea demasiado tarde.</p>
                        <a href="salas.jsp" class="btn btn-primary">Ver Detalles</a>
                    </div>
                </div>
                <div class="escape-room">
                    <img src="images/sala3.jpg" alt="Sala de escape" class="escape-room-img">
                    <div class="escape-room-content">
                        <h3 class="escape-room-title">El Tesoro Perdido</h3>
                        <span class="escape-room-difficulty">Dificultad: Baja</span>
                        <p class="escape-room-description">Ideal para centros educativos. Una aventura de aprendizaje en busca de un tesoro histórico.</p>
                        <a href="salas.jsp" class="btn btn-primary">Ver Detalles</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta">
        <div class="container">
            <div class="cta-content">
                <h2>¿Listo para la aventura?</h2>
                <p>Regístrate ahora y comienza a disfrutar de nuestras salas de escape online.</p>
                <a href="registro.jsp" class="btn btn-accent">Comenzar Ahora</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
