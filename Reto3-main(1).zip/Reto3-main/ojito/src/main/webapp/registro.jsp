<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - BilboSKP</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Bilbo<span>SKP</span></div>
                <ul class="nav-links">
                    <li><a href="index.jsp">Inicio</a></li>
                    <li><a href="salas.jsp">Salas de Escape</a></li>
                    <li><a href="cupones.jsp">Cupones</a></li>
                    <li><a href="login.jsp">Iniciar Sesión</a></li>
                    <li><a href="registro.jsp" class="btn btn-accent">Registrarse</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="registro">
        <div class="container">
            <h2 class="section-title">Elige tu tipo de registro</h2>
            
            <div class="registro-options">
                <div class="card">
                    <div class="card-header">
                        <h3>Usuario Normal</h3>
                    </div>
                    <div class="card-body">
                        <p>Accede a todas nuestras salas de escape online con una suscripción de solo 15€.</p>
                        <ul>
                            <li>Cupón gratuito al registrarte</li>
                            <li>Acceso a todas las salas generales</li>
                            <li>Posibilidad de comprar paquetes de cupones</li>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <a href="pago-suscripcion.jsp?tipo=usuario" class="btn btn-primary">Pagar Suscripción</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3>Centro Educativo</h3>
                    </div>
                    <div class="card-body">
                        <p>Suscripción gratuita para centros educativos verificados.</p>
                        <ul>
                            <li>Cupones gratuitos según número de alumnos</li>
                            <li>Acceso a salas exclusivas para centros</li>
                            <li>Sistema de rankings por aulas</li>
                            <li>Organización de partidas para alumnos</li>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <a href="registro-centro.jsp" class="btn btn-secondary">Solicitar Registro</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>BilboSKP</h3>
                    <p>La mejor plataforma de salas de escape online para usuarios y centros educativos.</p>
                </div>
                <div class="footer-section">
                    <h3>Enlaces Rápidos</h3>
                    <ul>
                        <li><a href="index.jsp">Inicio</a></li>
                        <li><a href="salas.jsp">Salas de Escape</a></li>
                        <li><a href="cupones.jsp">Cupones</a></li>
                        <li><a href="login.jsp">Iniciar Sesión</a></li>
                        <li><a href="registro.jsp">Registrarse</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contacto</h3>
                    <p>Email: info@bilboskp.com</p>
                    <p>Teléfono: +34 123 456 789</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 BilboSKP. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>
</body>
</html>
