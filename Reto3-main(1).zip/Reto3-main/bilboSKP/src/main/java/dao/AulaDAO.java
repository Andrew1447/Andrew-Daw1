package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Aula;

public class AulaDAO {

	public boolean addAula(Aula nuevoAula) {
		Connection con = AccesoBD.getConnection();
		PreparedStatement ps = null;

		String sql = "INSERT INTO aula (nombre_aula) VALUES (?)";

		try {
			ps = con.prepareStatement(sql);

			ps.setString(1, nuevoAula.getNombre_aula());

			if (ps.executeUpdate() > 0) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			AccesoBD.closeConnection(null, ps, con);
		}
		return false;
	}
}
