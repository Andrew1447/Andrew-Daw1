package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Partida;

public class PartidaDAO {

    // Crear nueva partida
    public boolean addPartida(Partida nuevaPartida) {
        String sql = "INSERT INTO partida (id_centro, id_aula, num_jugadores, dificultad) VALUES (?, ?, ?, ?)";
        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, nuevaPartida.getId_centro());
            ps.setInt(2, nuevaPartida.getId_aula());
            ps.setInt(3, nuevaPartida.getNum_jugadores());
            ps.setString(4, nuevaPartida.getDificultad());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        nuevaPartida.setCod_partida(rs.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Obtener partida por c�digo
    public Partida getPartidaByCodigo(int codPartida) {
        String sql = "SELECT * FROM partida WHERE cod_partida = ?";
        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, codPartida);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Partida(
                        rs.getInt("cod_partida"),
                        rs.getInt("id_centro"),
                        rs.getInt("id_aula"),
                        rs.getInt("num_jugadores"),
                        rs.getString("dificultad")
                    );
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Obtener todas las partidas
    public List<Partida> getAllPartidas() {
        List<Partida> partidas = new ArrayList<>();
        String sql = "SELECT * FROM partida";

        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                partidas.add(new Partida(
                    rs.getInt("cod_partida"),
                    rs.getInt("id_centro"),
                    rs.getInt("id_aula"),
                    rs.getInt("num_jugadores"),
                    rs.getString("dificultad")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return partidas;
    }

    // Obtener partidas por centro educativo
    public List<Partida> getPartidasByCentroEducativo(int idCentro) {
        List<Partida> partidas = new ArrayList<>();
        String sql = "SELECT * FROM partida WHERE id_centro = ?";

        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCentro);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    partidas.add(new Partida(
                        rs.getInt("cod_partida"),
                        rs.getInt("id_centro"),
                        rs.getInt("id_aula"),
                        rs.getInt("num_jugadores"),
                        rs.getString("dificultad")
                    ));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return partidas;
    }

    // Obtener partidas por aula
    public List<Partida> getPartidasByAula(int idAula) {
        List<Partida> partidas = new ArrayList<>();
        String sql = "SELECT * FROM partida WHERE id_aula = ?";

        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAula);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    partidas.add(new Partida(
                        rs.getInt("cod_partida"),
                        rs.getInt("id_centro"),
                        rs.getInt("id_aula"),
                        rs.getInt("num_jugadores"),
                        rs.getString("dificultad")
                    ));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return partidas;
    }

    // Actualizar partida
    public boolean updatePartida(Partida partida) {
        String sql = "UPDATE partida SET id_centro = ?, id_aula = ?, num_jugadores = ?, dificultad = ? WHERE cod_partida = ?";
        try (Connection con = AccesoBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, partida.getId_centro());
            ps.setInt(2, partida.getId_aula());
            ps.setInt(3, partida.getNum_jugadores());
            ps.setString(4, partida.getDificultad());
            ps.setInt(5, partida.getCod_partida());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Eliminar partida
    public boolean deletePartida(int codPartida) {
        String deletePuntuacionSql = "DELETE FROM puntuacion_total WHERE cod_partida = ?";
        String deleteJugadorSql = "DELETE FROM jugador WHERE cod_partida = ?";
        String deletePartidaSql = "DELETE FROM partida WHERE cod_partida = ?";

        try (Connection con = AccesoBD.getConnection()) {

            try (PreparedStatement ps1 = con.prepareStatement(deletePuntuacionSql)) {
                ps1.setInt(1, codPartida);
                ps1.executeUpdate();
            }

            try (PreparedStatement ps2 = con.prepareStatement(deleteJugadorSql)) {
                ps2.setInt(1, codPartida);
                ps2.executeUpdate();
            }

            try (PreparedStatement ps3 = con.prepareStatement(deletePartidaSql)) {
                ps3.setInt(1, codPartida);
                return ps3.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
