package service;

import java.util.List;

import dao.PartidaDAO;
import model.Partida;

public class PartidaService {
    
    private PartidaDAO partidaDAO;
    
    public PartidaService() {
        this.partidaDAO = new PartidaDAO();
    }
    
    // Create a new game
    public Partida createPartida(int idCentro, int idAula, int numJugadores, String dificultad) {
        Partida partida = new Partida(0, idCentro, idAula, numJugadores, dificultad);
        
        boolean success = partidaDAO.addPartida(partida);
        
        if (success) {
            return partida;
        } else {
            return null;
        }
    }
    
    // Get a game by its code
    public Partida getPartidaByCodigo(int codPartida) {
        return partidaDAO.getPartidaByCodigo(codPartida);
    }
    
    // Get all games
    public List<Partida> getAllPartidas() {
        return partidaDAO.getAllPartidas();
    }
    
    // Get games by educational center
    public List<Partida> getPartidasByCentroEducativo(int idCentro) {
        return partidaDAO.getPartidasByCentroEducativo(idCentro);
    }
    
    // Get games by classroom
    public List<Partida> getPartidasByAula(int idAula) {
        return partidaDAO.getPartidasByAula(idAula);
    }
    
    // Update a game
    public boolean updatePartida(Partida partida) {
        return partidaDAO.updatePartida(partida);
    }
    
    // Delete a game
    public boolean deletePartida(int codPartida) {
        return partidaDAO.deletePartida(codPartida);
    }
}